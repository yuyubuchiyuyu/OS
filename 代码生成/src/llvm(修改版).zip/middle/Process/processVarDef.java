package middle.Process;

import frontend.Lexer.Token;
import frontend.Parser.Class.BType;
import frontend.Parser.Class.Exp;
import frontend.Parser.Class.VarDef;
import middle.Class.Instruction.AllocaInst;
import middle.Class.Instruction.GetelementptrInstr;
import middle.Class.Instruction.StoreInst;
import middle.Class.Instruction.TransferInst;
import middle.Class.IrType.IrType;
import middle.Count;
import middle.Symbol.Symbol;
import middle.Symbol.SymbolTable;
import middle.Value;

import java.util.ArrayList;

public class processVarDef {
    public static ArrayList<Value> processVarDef(VarDef varDef, BType bType, SymbolTable symbolTable) {
        ArrayList<Value> instructions = new ArrayList<>();
        String ident = varDef.getIdent();
        String name = "%LocalVariable_" + Count.getFuncInner();
        Integer dimension = varDef.getDimension();
        IrType irType;
        int bTypeSymbol;    // 填表用
        if (dimension == 0) {
            Integer value;
            if (bType.getBType() == Token.tokenType.INTTK) {
                bTypeSymbol = 0;
                irType = new IrType(IrType.TypeID.IntegerTyID, 32);
            } else {
                bTypeSymbol = 1;
                irType = new IrType(IrType.TypeID.IntegerTyID, 8);
            }
            Symbol symbol = new Symbol(ident, name, irType, 0, bTypeSymbol, 1);
            symbolTable.addSymbol(symbol);
            AllocaInst allocaInst = new AllocaInst(name, irType);
            instructions.add(allocaInst);
            if (varDef.getInitVal() != null && varDef.getInitVal().getExp() != null) {
                Exp exp = varDef.getInitVal().getExp();
                if (exp.judgeCalculate(symbolTable)) {    // 初值可以计算得到
                    value = exp.calculate(symbolTable);
                    if (irType.getNum() == 8) {
                        value = value % 256;
                    }
                    symbol.setValue(value);
                    StoreInst storeInst = new StoreInst(irType, value, symbol.irName);
                    instructions.add(storeInst);
                } else {
                    instructions.addAll(exp.getCalInstructions(symbolTable));
                    TransferInst.typeTransfer(instructions, irType);
                    StoreInst storeInst = new StoreInst(irType,
                            instructions.get(instructions.size() - 1).getResName(), symbol.irName);
                    instructions.add(storeInst);
                }
            }
        } else {
            Integer size = varDef.getConstExp().calculate(symbolTable);
            Symbol symbol;
            if (bType.getBType() == Token.tokenType.INTTK) {
                irType = new IrType(IrType.TypeID.PointerTyID, 32);
                symbol = new Symbol(ident, name, irType, 1, 0, 1, size);
            } else {
                irType = new IrType(IrType.TypeID.PointerTyID, 8);
                symbol = new Symbol(ident, name, irType, 1, 1, 1, size);
            }
            symbolTable.addSymbol(symbol);
            IrType valueIrType = symbol.valueIrType;
            AllocaInst allocaInst = new AllocaInst(name, valueIrType, size);
            instructions.add(allocaInst);
            if (varDef.getInitVal() != null) {
                if (varDef.getInitVal().getExps() != null) {
                    int offset = 0;
                    ArrayList<Exp> exps = varDef.getInitVal().getExps();
                    while (offset < exps.size()) {
                        String geteName = "%LocalVariable_" + Count.getFuncInner();
                        GetelementptrInstr getelementptrInstr = new GetelementptrInstr(geteName, symbol, offset);
                        instructions.add(getelementptrInstr);
                        Exp exp = exps.get(offset);
                        if (exp.judgeCalculate(symbolTable)) {
                            Integer value = exp.calculate(symbolTable);
                            if (irType.getNum() == 8) {
                                value = value % 256;
                            }
                            symbol.setArrayValue(value);
                            StoreInst storeInst = new StoreInst(valueIrType, value, geteName);
                            instructions.add(storeInst);
                        } else {
                            instructions.addAll(exp.getCalInstructions(symbolTable));
                            TransferInst.typeTransfer(instructions, irType);
                            StoreInst storeInst = new StoreInst(valueIrType, instructions.get(instructions.size() - 1).getResName(), geteName);
                            instructions.add(storeInst);
                        }
                        offset = offset + 1;
                    }
                    if (bType.getBType() != Token.tokenType.INTTK) {    // 唯一不需要编译器置0的情况只有局部变量int数组部分初始化。
                        while (offset < size) {
                            String geteName = "%LocalVariable_" + Count.getFuncInner();
                            GetelementptrInstr getelementptrInstr = new GetelementptrInstr(geteName, symbol, offset);
                            instructions.add(getelementptrInstr);
                            symbol.setArrayValue(0);
                            StoreInst storeInst = new StoreInst(valueIrType, 0, geteName);
                            instructions.add(storeInst);
                            offset = offset + 1;
                        }
                    }
                } else if (varDef.getInitVal().getStringConst() != null) {
                    int offset = 0;
                    String stringConstTemp = varDef.getInitVal().getStringConst();
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i = 0; i < stringConstTemp.length() - 2; i++) {
                        stringBuilder.append(stringConstTemp.charAt(i + 1));
                    }
                    String stringConst = stringBuilder.toString();
                    while (offset < size) {
                        String geteName = "%LocalVariable_" + Count.getFuncInner();
                        GetelementptrInstr getelementptrInstr = new GetelementptrInstr(geteName, symbol, offset);
                        instructions.add(getelementptrInstr);
                        Integer value = 0;
                        if (offset < stringConst.length()) {
                            value = (int) stringConst.charAt(offset);
                        }
                        symbol.setArrayValue(value);
                        StoreInst storeInst = new StoreInst(valueIrType, value, geteName);
                        instructions.add(storeInst);
                        offset = offset + 1;
                    }
                }
            }
        }
        return instructions;
    }
}
