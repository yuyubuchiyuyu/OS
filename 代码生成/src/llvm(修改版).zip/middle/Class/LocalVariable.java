package middle.Class;

public class LocalVariable {
}
