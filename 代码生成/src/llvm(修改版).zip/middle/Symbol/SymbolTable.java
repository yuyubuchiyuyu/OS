package middle.Symbol;

import java.util.*;

public class SymbolTable {


    private ArrayList<Symbol> symbolList;
    private SymbolTable father;

    public SymbolTable(SymbolTable father) {
        this.symbolList = new ArrayList<>();
        this.father = father;
    }

    public void addSymbol(Symbol symbol) {
        symbolList.add(symbol);
    }

    public Symbol search(String ident) {
        SymbolTable symbolTable = this;
        while(symbolTable!=null){
            for(Symbol symbol:symbolTable.symbolList){
                if(Objects.equals(symbol.name, ident)){
                    return symbol;
                }
            }
            symbolTable = symbolTable.father;
        }
        return null;
    }

    public SymbolTable getFather() {
        return father;
    }
}
