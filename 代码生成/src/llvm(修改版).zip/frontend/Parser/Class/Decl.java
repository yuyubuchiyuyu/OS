package frontend.Parser.Class;

import java.util.ArrayList;

public class Decl {
    protected void printName(ArrayList<String> outputList) {
        // outputList.add("<Decl>");
    }
}
