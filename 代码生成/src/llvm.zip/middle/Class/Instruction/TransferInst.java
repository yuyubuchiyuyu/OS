package middle.Class.Instruction;

import middle.Class.IrType.IrType;
import middle.Value;

public class TransferInst extends Value {
    private String resName = null;
    private IrType irType1 = null;
    private IrType irType2 = null;
    private Integer value = null;
    private String name = null;

    public TransferInst(String resName, Integer value, IrType irType1, IrType irType2) {
        this.resName = resName;
        this.value = value;
        this.irType1 = irType1;
        this.irType2 = irType2;
    }

    public TransferInst(String resName, String name, IrType irType1, IrType irType2) {
        this.resName = resName;
        this.name = name;
        this.irType1 = irType1;
        this.irType2 = irType2;
    }

    public String getResName() {
        return resName;
    }

    public IrType getResIrType() {
        return irType2;
    }

    public String getOutput() {
        if (value != null) {
            if (irType1.getNum() < irType2.getNum()) {
                return resName + " = zext " + irType1.getOutput() + " " + value + " to " + irType2.getOutput();
            } else {
                return resName + " = trunc " + irType1.getOutput() + " " + value + " to " + irType2.getOutput();
            }
        } else {
            if (irType1.getNum() < irType2.getNum()) {
                return resName + " = zext " + irType1.getOutput() + " " + name + " to " + irType2.getOutput();
            } else {
                return resName + " = trunc " + irType1.getOutput() + " " + name + " to " + irType2.getOutput();
            }
        }

    }
}
