package middle;

public class User extends Value{
}
