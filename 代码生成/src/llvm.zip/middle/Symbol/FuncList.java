package middle.Symbol;

import java.util.ArrayList;
import java.util.HashMap;

public class FuncList {
    private HashMap<String, SymbolTable> functions;

    public FuncList() {
        this.functions = new HashMap<>();
    }

    public void addFunc(String ident,SymbolTable symbolTable) {
        functions.put(ident,symbolTable);
    }
}
