package middle;

import middle.Class.IrType.IrType;

public class Value {
    public String getOutput() {
        return "";
    }

    public String getResName() {
        return null;
    }

    public IrType getResIrType() {
        return null;
    }
}
