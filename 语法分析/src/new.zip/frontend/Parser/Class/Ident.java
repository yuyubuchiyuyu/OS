package frontend.Parser.Class;

public class Ident {
    String text;
    public Ident(String text) {
        this.text = text;
    }
}
